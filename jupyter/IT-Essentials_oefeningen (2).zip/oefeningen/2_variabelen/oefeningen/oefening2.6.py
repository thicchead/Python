PI = 3.14159
straal = float(input("Geef de straal van de cirkel: "))

oppervlakte = straal * straal * PI

print("De oppervlakte van een cirkel met straal", straal, "is", oppervlakte)