a = int(input("Geef een getal in: "))
b = int(input("Geef een getal in: "))

print("a =", a, "b= ", b)

a = a + b
b = a - b
a = a - b

print("a =", a, "b =", b)