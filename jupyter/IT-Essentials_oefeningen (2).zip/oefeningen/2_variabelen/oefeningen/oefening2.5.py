fahrenheit = int(input("Geef het aantal graden Fahreneheit: "))

celcius = (fahrenheit - 32) / (9/5)
celcius_afgerond = int(celcius * 10 + 0.5) / 10

print(fahrenheit, "graden Fahrenheit is gelijk aan", celcius_afgerond, "graden Celcius.")

