aantal_volwassenen = int(input("Geef het aantal volwassenen: "))
aantal_kinderen = int(input("Geef het aantal kinderen: "))

totale_prijs = (aantal_volwassenen * 11) + (aantal_kinderen * 6)

print("De totale prijs is", totale_prijs)