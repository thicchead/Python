afgelegde_km = float(input("Geef het aantal afgelegde km per jaar: "))
verbuik = float(input("Geef het verbuik in liter per 100 km: ")) / 100
prijs_per_liter = float(input("Geef de prijs per liter brandstof: "))

kostprijs_per_km = prijs_per_liter * verbuik
totale_kostprijs = kostprijs_per_km * afgelegde_km

print("De totale kostprijs per jaar voor het opgegeven aantal km bedraagt", totale_kostprijs, "euro\nDe kostprijs per km rijden bedraagt", kostprijs_per_km, "euro")

print(5 % 2)