lengte = float(input("Geef de lengte (in meter) van het tapijt: "))
breedte = float(input("Geef de breedte (in meter) van het tapijt: "))
prijs_per_m2 = float(input("Geef de prijs per m²: "))
plaatsingskosten_per_m2 = float(input("Geef de plaatsingskosten per m²: "))

oppervlakte = lengte * breedte
kostprijs_tapijt = oppervlakte * prijs_per_m2
plaatsingskosten = oppervlakte * plaatsingskosten_per_m2
totale_kosten = kostprijs_tapijt + plaatsingskosten

print("De kostprijs van de tapijt bedraagt", kostprijs_tapijt, "euro\nDe plaatsingskosten bedraagt", plaatsingskosten, "euro\nDe totale kosten bedraagt", totale_kosten, "euro")

