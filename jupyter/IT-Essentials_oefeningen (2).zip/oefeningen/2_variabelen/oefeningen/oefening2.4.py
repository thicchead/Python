celcius = int(input("Geef het aantal graden Celcius: "))

fahrenheit = (9/5) * celcius + 32

print(celcius, "graden Celcius is gelijk aan", fahrenheit, "graden Fahrenheit.")