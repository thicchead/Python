var1 = int(input("Geef een eerste geheel getal in: "))
var2 = int(input("Geef een tweede geheel getal in: "))
var3 = int(input("Geef een derde geheel getal in: "))

gemiddelde = (var1 + var2 + var3) / 3

print("Het gemiddelde is ", gemiddelde)
