lengte = float(input("Geef je lengte (in meter): "))
gewicht = float(input("Geef je gewicht (in kg): "))

bmi = gewicht / (lengte * lengte)
bmi = int(bmi * 10) / 10

print("Jouw BMI is", bmi)