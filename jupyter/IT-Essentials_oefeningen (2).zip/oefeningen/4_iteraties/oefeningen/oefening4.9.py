for i in range (2,6):
    for j in range(1,21):
        print(i, "x", j, "=", i * j)
    print()