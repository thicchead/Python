getal = int(input("Geef een getal in: "))
for i in range(1,21):
    print(i, "x", getal, "=", i * getal)















