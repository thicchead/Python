getal = int(input("Geef een getal in: "))
teller_negatief = 0
som = 0
while getal != 0:
    if getal < 0:
        teller_negatief += 1
    som += getal
    getal = int(input("Geef een getal in: "))
print("Som van de ingegeven getallen:", som)
print("Aantal negatieve getallen:", teller_negatief)
