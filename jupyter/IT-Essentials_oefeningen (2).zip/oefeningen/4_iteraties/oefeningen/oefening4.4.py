gewicht_maan = float(input("Percentage maan t.o.v. aarde: ")) / 100
gewicht_jupiter = float(input("Percentage jupiter t.o.v. aarde: ")) / 100
gewicht_mars = float(input("Percentage mars t.o.v. aarde: ")) / 100

for i in range(50,125,5):
    print("Aarde:", i)
    print("Maan:", i * gewicht_maan)
    print("Jupiter:", i * gewicht_jupiter)
    print("Mars:", i * gewicht_mars)
    print()