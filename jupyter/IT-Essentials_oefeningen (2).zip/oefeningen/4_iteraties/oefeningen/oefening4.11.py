personeelsnummer = int(input("Geef het personeelsnummer: "))
teller_man = 0
teller_vrouw = 0

while personeelsnummer != 0:
    geslacht = int(input("Geef het geslacht (0 = vrouw, 1 = man): "))
    while not (geslacht == 0 or geslacht == 1):
        geslacht = int(input("Foute ingave! Geef het geslacht (0 = vrouw, 1 = man): "))
    leeftijd = int(input("Geef de leeftijd: "))
    brutoloon = int(input("Geef het brutoloon: "))

    if geslacht == 1:
        if leeftijd > 34 or brutoloon >= 1800:
            teller_man +=1
    else:
        if leeftijd < 25:
            teller_vrouw +=1
    personeelsnummer = int(input("Geef het personeelsnummer: "))

print("Aantal mannelijke personen ouder dan 34 of een loon hebben van 1800 euro of meer:", teller_man)
print("Aantal vrouwelijke personen jonger dan 25:", teller_vrouw)