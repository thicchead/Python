familienaam = input("Geef de familienaam in: ")
hoogste = 0
som = 0

while familienaam != "/" and familienaam != "*":
    voornaam = input("Geef de voornaam in: ")
    aantal_dienstjaren = int(input("Geef het aantal dienstjaren in: "))
    while not (aantal_dienstjaren >= 0 and aantal_dienstjaren <= 40):
        aantal_dienstjaren = int(input("Foute ingave! Geef het aantal dienstjaren in: "))
    if aantal_dienstjaren < 5:
        premie = 0
    else:
        premie = aantal_dienstjaren * 25
        if premie > hoogste:
            hoogste = premie
        som += premie
    print("Naam:", familienaam, voornaam, "\nAantal dienstjaren:", aantal_dienstjaren, "\nPremie:", premie)
    familienaam = input("Geef de familienaam in: ")
print("Totale premie:", som)
print("Hoogste premie:", hoogste)















