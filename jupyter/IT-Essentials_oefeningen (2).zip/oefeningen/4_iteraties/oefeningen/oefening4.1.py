gewicht = int(input("Geef het gewicht in: "))
for i in range(1,101):
    print(i, "appel(s) =", i * gewicht, "gr.")


















