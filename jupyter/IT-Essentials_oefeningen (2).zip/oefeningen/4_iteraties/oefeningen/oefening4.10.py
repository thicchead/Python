for i in range(1, 11):
    for j in range(1, 12 - i):
        print("@", end=" ")
    print()
print()

for i in range(1, 11):
    for j in range(1, 1 + i):
        print("@", end=" ")
    print()