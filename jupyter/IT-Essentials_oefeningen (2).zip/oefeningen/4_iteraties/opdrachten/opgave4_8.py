# afdruk van alle getallen tussen 0 en 10000 (grenzen inbegrepen) die deelbaar
# zijn door 6 en door 28
for i in range(0, 10001):
    if i % 6 == 0 and i % 28 == 0:
        print(i)
print()
# efficientere oplossing (= beter)
for i in range(0, 10001, 6):
    if i % 28 == 0:
        print(i)
print()
# efficientere oplossing
for i in range(0, 10001, 28):
    if i % 6 == 0:
        print(i)
print()
# efficienste oplossing zonder een if
for i in range(0, 10001, 84): #  kleinste gemeen veelvoud van 28 en 6
    print(i)





