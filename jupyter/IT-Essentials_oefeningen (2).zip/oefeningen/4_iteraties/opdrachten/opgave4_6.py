# druk alle veelvouden van 7 kleiner dan 200 af
for i in range(0, 200, 7):
    print(i)