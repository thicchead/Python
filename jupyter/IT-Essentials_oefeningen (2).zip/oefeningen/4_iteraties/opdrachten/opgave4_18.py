# Belangrijk!!!! invoercontrole  ingegeven getal moet tussen 0 en 10 liggen (grenzen exclusief)
# invoercontrole steeds while gebruken NOOIT een if
getal = int(input("geef een getal tussen 0 en 10 in "))
while getal <= 0 or getal >= 10: # of not (getal > 0 and getal < 10)
    getal = int(input("Foutief getal geef het opnieuw in "))
