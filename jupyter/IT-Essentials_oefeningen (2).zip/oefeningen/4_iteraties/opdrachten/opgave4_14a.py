# bereken de som van een reeks getallen. invoer stopt bij ingave 0.
som = 0
getal = int(input("geef een geheel getal in "))
while getal != 0:
    som += getal # som = som + getal
    getal = int(input("geef een geheel getal in "))
print("de som van deze getallen in", som)

# extra opgave: bereken het product van een reeks getallen. Invoer stopt bij ingave 0.
prod = 1
getal = int(input("geef een geheel getal in "))
while getal != 0:
    prod *= getal # prod = prod * getal
    getal = int(input("geef een geheel getal in "))
print("de prod van deze getallen in", prod)