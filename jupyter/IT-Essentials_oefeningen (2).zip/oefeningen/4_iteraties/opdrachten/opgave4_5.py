# getallen van 400 tem 350 afdrukken te beginnen met 400
for i in range(400, 349, -1):
    print(i)