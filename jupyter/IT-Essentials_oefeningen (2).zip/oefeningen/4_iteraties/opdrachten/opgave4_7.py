# druk alle getallen vn -10 tem +10 af.
# De strikt positieve getallen moeten voorafgegaan worden door een +
# opm positief getal >= 0, strikt positief >0; negatief getal <= 0 strikt negatief < 0
for i in range(-10, 11):
    if i > 0:
        print("+" + str(i))
    else:
        print(i)

# efficienter zonder een test te moeten uitvoeren
for i in range(-10, 1):
    print(i)
for i in range(1, 11):
    print("+" + str(i))

