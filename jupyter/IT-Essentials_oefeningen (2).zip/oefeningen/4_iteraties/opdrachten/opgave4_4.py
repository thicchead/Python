for i in range(1,7,2):
    print(i)
    print("De waarde van het kwadraat van", i, "is", i * i)
print("De waarde van i na afloop van de for-lus", i)