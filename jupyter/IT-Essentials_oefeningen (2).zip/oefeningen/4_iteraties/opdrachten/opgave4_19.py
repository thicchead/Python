for i in range(1, 6): # rij per rij
    for j in range(1, 11):
        print( i * j, end= "\t")
    print()

for j in range(1, 11):#kolom per kolom
    for i in range(1, 6):
       print( i * j, end= "\t")
    print()