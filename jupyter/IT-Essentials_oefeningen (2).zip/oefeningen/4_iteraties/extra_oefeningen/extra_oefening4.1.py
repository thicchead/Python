for i in range(1,26):
    print(i, "jetons =", (int(i * 0.7 * 10 + 0.5)) / 10)
for i in range(30,55,5):
    print(i, "jetons =", (int(i * 0.7 * 10 + 0.5)) / 10)