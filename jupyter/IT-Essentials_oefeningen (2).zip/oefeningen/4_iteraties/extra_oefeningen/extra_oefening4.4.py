geslacht = int(input("Geef het geslacht (1 = man, 2 = vrouw): "))
slecht_man = 0
slecht_vrouw = 0
teller = 0

while geslacht == 1 or geslacht == 2:
    afstand = float(input("Geef de afgelegde afstand in: "))
    conditie_getal = (afstand * 1000 - 504.9) / 44.73
    if conditie_getal < 36 and geslacht == 1:
        slecht_man +=1
    elif conditie_getal < 29 and geslacht == 2:
        slecht_vrouw +=1
    teller +=1
    geslacht = int(input("Geef het geslacht (1 = man, 2 = vrouw): "))
percentage = int(((slecht_man + slecht_vrouw) / teller) * 10 + 0.5) /10
print("Percentage werknemers die een slechte conditie hebben:", percentage)