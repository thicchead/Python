for i in range(1200):
    som = 0
