naam = input("Geef de naam in: ")
while naam != "xx" and naam != "XX":
    percentage = int(input("Geef percentage in: "))
    while not(percentage >= 0 and percentage <= 100):
        if percentage < 0:
            percentage = int(input("Fout! Het getal moet minstens 0 zijn.\nGeef percentage in: "))
        else:
            percentage = int(input("Fout! Het getal mag maximum 100 zijn.\n Geef percentage in: "))
    if percentage >= 85:
        graad = "grootste onderscheiding"
    elif percentage >= 80:
        graad = "grote onderscheiding"
    elif percentage >= 70:
        graad = "onderscheiding"
    elif percentage >= 60:
        graad = "voldoende"
    else:
        graad = "onvoldoende"

    print(naam, ":", graad)
    naam = input("Geef de naam in: ")