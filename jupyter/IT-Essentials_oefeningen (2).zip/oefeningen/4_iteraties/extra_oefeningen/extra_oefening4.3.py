naam = input("Geef de naam in: ")
teller = 0
teller_geslaagd = 0
while naam != "xx" and naam != "XX":
    test1 = int(input("Test1: "))
    test2 = int(input("Test2: "))
    test3 = int(input("Test3: "))
    gemiddelde = int(((test1 + test2 + test3) / 3) * 10 + 0.5) / 10
    if gemiddelde < 70:
        resultaat = "faalt"
    else:
        resultaat = "slaagt"
        teller_geslaagd +=1
    teller +=1
    print(naam, "Test1:", test1, "Test2:", test2, "Test3:", test3, "Gemiddelde:", gemiddelde, "Resultaat:", resultaat)
    naam = input("Geef de naam in: ")
procent = teller_geslaagd / teller * 100
print("Er slaagden", int(procent * 10 + 0.5) / 10, "% van de", teller, "deelnemende managers.")