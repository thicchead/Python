getal = int(input("Geef een getal in: "))
while getal != 0:
    vorig = getal


    getal = int(input("Geef een getal in: "))
