print(7+5)
print("Dit is een test \nvoor \t1TINB")