# aantal seconden in 2 weken
print(2*7*24*60*60)

# 729 appels te verdelen over 18 studenten Hoeveel appels blijven er over?
print(729%18)