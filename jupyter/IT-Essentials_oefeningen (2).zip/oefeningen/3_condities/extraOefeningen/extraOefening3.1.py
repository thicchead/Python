a = float(input("Geef een getal in: "))
b = float(input("Geef een tweede getal in: "))
c = float(input("Geef een derde getal in: "))

som = a + b
if som < 20:
    som += c
    print("De som van de 3 getallen is", som)
else:
    print("Te groot.")
