verbruik = int(input("Geef het verbruik in: "))

prijs = 25
if verbruik > 30 and verbruik <= 200:
    prijs += 1 * (verbruik - 30)
elif verbruik < 5000:
    prijs += 1.15 * (verbruik - 30)
else:
    prijs += 1.175 * (verbruik - 30)

print("Prijs:", prijs)