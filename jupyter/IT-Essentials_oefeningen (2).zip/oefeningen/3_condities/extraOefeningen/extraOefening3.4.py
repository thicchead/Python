naam = input("Naam speler: ")
prijs_vorig_seizoen = int(input("Prijs vorig seizoen: "))
leeftijd = int(input("Leeftijd: "))
beoordelingscijfer = int(input("Gemiddelde beoordelingscijfer: "))
type = input("Type speler: ")
doelpunten = int(input("Aantal doelpunten: "))

prijs = prijs_vorig_seizoen
if leeftijd < 25:
    prijs *= 1.1
elif leeftijd > 30:
    prijs *= 0.95

if type == "aanvaller":
    if doelpunten < 6:
        prijs += 10000 * doelpunten
    else:
        prijs += 20000 * (doelpunten - 5) + (5 * 10000)
else:
    prijs += 10000 * beoordelingscijfer
    if type == "doelman" and doelpunten >= 20:
        prijs -= 9000 * (doelpunten - 20)
print("Naam:", naam, "\nPrijs vorig seizoen:", prijs_vorig_seizoen, "\nNieuwe prijs:", prijs)

