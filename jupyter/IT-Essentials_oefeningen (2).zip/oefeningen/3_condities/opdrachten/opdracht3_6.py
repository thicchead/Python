# opgave 3.8 uit de cursus
getal = int(input("geef een geheel getal in "))
if getal % 2 == 0: # deelbaar door 2
    print("even")
else:
    print("oneven")

# deelbaar door 7? getal % 7 == 0