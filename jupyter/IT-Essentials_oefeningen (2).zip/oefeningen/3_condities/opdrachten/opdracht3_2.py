# opgave 3.2 uit cursus
print(1 / 10 == 0.10)  # True
print(1 / 10 > 0.10)  # False

print(1 / 3 == 0.33)  # False
print(1 / 3 > 0.33)  # True

print((1 / 3) * 3 == 1)  # True
print((1 / 3) * 3 > 1)  # False

print(1 / 10 + 1 / 10 + 1 / 10 == 0.3)  # True => geeft false omwille van afrondingsfouten
print(1 / 10 + 1 / 10 + 1 / 10 > 0.3)  # False => geeft true omwille van afrondingsfouten

print(1 / 10)
print(1 / 10 + 1 / 10 + 1 / 10)
