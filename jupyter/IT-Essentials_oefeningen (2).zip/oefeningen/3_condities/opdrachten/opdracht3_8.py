# opgave 3.10 uit cursus < 20 , > 20, == 20
gewicht = int(input("geef het gewicht van je bagage in "))
if gewicht < 20:
    print("Goede reis!")
elif gewicht == 20:
    print("Poeh! Dat gewicht is percies goed!")
else:   # niet oké elif gewicht > 20:
    print("Er moet een toeslag van 25 euro betaald worden voor bagage die te zwaar is")
