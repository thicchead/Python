#opgave 3.3 uit de cursus komt e, x, Van voor in je naam
print("e" in "Ingrid Vanherwegen")
print("x" in "Ingrid Vanherwegen")
print("Van" in "Ingrid Vanherwegen")