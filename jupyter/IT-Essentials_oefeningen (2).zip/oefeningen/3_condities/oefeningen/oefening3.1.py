getal1 = int(input("Geef een geheel getal in: "))
getal2 = int(input("Geef een geheel getal in: "))

if getal1 == getal2:
    print("De twee getallen zijn gelijk.")
else:
    print("De twee getallen zijn ongelijk.")

