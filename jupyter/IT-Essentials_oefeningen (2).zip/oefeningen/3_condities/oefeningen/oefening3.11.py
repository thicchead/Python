sterren = int(input("Geef het aantal sterren: "))
code = input("Geef code voor ontbijt in: ")
aantal_overnachtingen = int(input("Geef aantal overnachtingen in: "))
seizoen = input("Geef code van seizoen in: ")

if sterren == 1:
    prijs = 30
elif sterren == 2 or sterren == 3:
    prijs = 40
else:
    prijs = 55

if code == "O":
    prijs *= 1.2
elif code == "H":
    prijs *= 1.5
elif code == "V":
    prijs *= 1.6
else:
    prijs *= 0.6 + 80

if seizoen == "L" and (code == "O" or code == "H"):
        prijs *= 0.9

prijs *= aantal_overnachtingen
print("De totale prijs is:", prijs)