def toon():
    a = 8
    b = 9
    print(a, b)

def main():
    a = 5
    b = 6
    toon()
    print(a, b)

if __name__ == '__main__':
    main()