def bereken(x, y):
    res = x * 2 + y * 3
    return res

def main():
    a = 5
    b = 7
    c = bereken(a, b)
    print(a, b, c)

if __name__ == '__main__':
    main()