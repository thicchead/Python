# zie extra opgave3 uit H4. Maak op een zinvolle manier gebruik van een functie.
# geef via toetsenbord code en tijd in
# code 1= met de bus, 2= te voet, 3= met de fiets, 4= met de trein, 5 = met de auto 0 om te eindigen
# tijd =  tijd in min om van huis naar school te gaan
# bereken de gemiddelde duur
# bereken de minimale tijd
# was dit met de bus, te voet, met de fiets, met de trein of met de auto
# percentage dat met de auto komt
# niet de code afdrukken R6 wel tekst
def bepaal_vervoersmiddel(code):
    if code == 1:
        vervoersmiddel = "met de bus"
    elif code == 2:
        vervoersmiddel = "te voet"
    elif code == 3:
        vervoersmiddel = "met de fiets"
    elif code == 4:
        vervoersmiddel = "met de trein"
    else:
        vervoersmiddel = "met de auto"
    return vervoersmiddel

def main():
    code = int(input("geef de code in "))
    minimum = 120  # intialisatie op een grote waarde!
    minimum_code = -1  # om te vermijden dat de interpreter foutmelding geeft bij afdrukken minimumcode
    teller = 0  # om aantal personen te tellen
    som = 0  # om de totale duur te berekenen
    teller_auto = 0  # om aantal personen te tellen die met de auto komt
    while code != 0:
        tijd = int(input("geef de tijd in"))
        teller += 1
        som += tijd
        if tijd < minimum:
            minimum = tijd
            minimum_code = code
        if code == 5:
            teller_auto += 1
        code = int(input("geef de code in "))
    gemiddelde = som / teller
    print("de gemiddelde tijd is", gemiddelde)
    print("de minimale tijd is", minimum)
    print("dit was met vervoerscode", minimum_code)
    vervoersmiddel = bepaal_vervoersmiddel(minimum_code)
    print("dit was", vervoersmiddel)
    # extra percentage afgerond op 1 cijfer na de komma
    percentage_auto = round(teller_auto / teller * 100)
    print("het percentage dat met de auto komt:", percentage_auto)

if __name__ == '__main__':
    main()