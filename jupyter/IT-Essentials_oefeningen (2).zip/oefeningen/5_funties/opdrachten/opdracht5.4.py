def is_even(getal):
    if getal % 2 == 0:
        return True
    else:
        return False

   # return getal % 2 == 0

def main():
    print(is_even(123456))
    print(is_even(121))

if __name__ == '__main__':
    main()