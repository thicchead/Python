def is_even(getal):
    return getal % 2 == 0

def is_oneven(getal):
    return not is_even(getal)
# gemakkelijkere maar niet de opgave return getal %2 != 0

def main():
    print(is_oneven(123456))
    print(is_oneven(121))

if __name__ == '__main__':
    main()