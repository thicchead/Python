def controleer_lidnummer(lidnummer):
    cijfer_2 = lidnummer // 100000 % 10
    cijfer_4 = lidnummer // 1000 % 10
    cijfers_laatste = lidnummer % 100
    if (cijfer_2 * 10 + cijfer_4) == cijfers_laatste:
        return "gratis"
    else:
        return "niet gratis"

def main():
    lidnummer = int(input("Geef het lidnummer in: "))
    print(controleer_lidnummer(lidnummer))

if __name__ == '__main__':
    main()