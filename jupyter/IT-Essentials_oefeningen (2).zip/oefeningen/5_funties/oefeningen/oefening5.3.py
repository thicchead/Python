def bereken_lidgeld(leeftijd, aantal_kinderen, inkomen, aansluitingsjaar):
    lidgeld = 100
    vermindering = aantal_kinderen * 7.5
    if vermindering > 35:
        vermindering = 35
    lidgeld -= vermindering
    if leeftijd > 60:
        lidgeld -= 15
    if 2021 - aansluitingsjaar > 20:
        lidgeld -= 12.5
    if inkomen < 7500:
        lidgeld -= 25
    if lidgeld < 50:
        lidgeld = 50
    return lidgeld

def main():
    naam = input("Geef een naam in: ")
    while naam != "x" and naam != "X":
        leeftijd = int(input("Geef de leeftijd in: "))
        aantal_kinderen = int(input("Geef het aantal kinderen in: "))
        inkomen = int(input("Geef het inkomen in: "))
        aansluitingsjaar = int(input("Geef het aansluitingsjaar in: "))
        lidgeld = bereken_lidgeld(leeftijd, aantal_kinderen, inkomen, aansluitingsjaar)
        print("Naam:", naam, "\nLidgeld:", lidgeld)
        naam = input("Geef een naam in: ")

if __name__ == '__main__':
    main()