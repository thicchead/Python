def bereken_prijs(oppervlakte):
    print()

def main():
    oppervlakte = int(input("Geef een oppervlakte in: "))
    prijs = bereken_prijs(oppervlakte)

if __name__ == '__main__':
    main()