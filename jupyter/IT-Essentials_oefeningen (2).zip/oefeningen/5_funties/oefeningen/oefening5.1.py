def omzetting_euro_dollar(euro, bedrag):
    omzetting = euro * bedrag

def main():
    euro = float(input("Geef de waarde van de euro t.o.v. de US dollar: "))
    bedrag = int(input("Geef een bedrag in euro: "))
    while euro != 0:
        omzetting = omzetting_euro_dollar(euro, bedrag)
        print(bedrag, "euro =", omzetting, "dollar.")
        bedrag = int(input("Geef een bedrag in euro: "))

if __name__ == '__main__':
    main()