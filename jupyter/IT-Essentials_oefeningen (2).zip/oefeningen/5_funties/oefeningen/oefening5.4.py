import random

def feedback_getal(willekeurig, getal):
    if willekeurig == getal:
        return "proficiat, getal geraden"
    elif willekeurig < getal:
        return "lager"
    else:
        return "hoger"

def main():
    teller = 0
    willekeurig = random.randint(1, 10)
    getal = int(input("Raad het willekeurig getal: "))
    while teller < 3:
        feedback = feedback_getal(willekeurig, getal)
        print(feedback)
        if feedback == "proficiat, getal geraden":
            teller = 3
        else:
            teller +=1
            getal = int(input("Raad het willekeurig getal: "))

if __name__ == '__main__':
    main()