def bereken_boete(aantal_boeken, aantal_dagen):
    boete = aantal_dagen * 0.07 * aantal_boeken
    if aantal_dagen >= 45:
        boete += 0.84
    return boete

def main():
    naam = input("Geef de naam in: ")
    aantal_brieven = 0
    while naam != "xx":
        aantal_boeken = int(input("Geef het aantal boeken in: "))
        aantal_dagen = int(input("Geef het aantal overschreden dagen in: "))
        boete = bereken_boete(aantal_boeken, aantal_dagen)
        if aantal_dagen >= 45:
            aantal_brieven +=1
        print("Naam:", naam, "\nBoete:", boete)
        naam = input("Geef de naam in: ")
    print("Totaal aantal brieven:", aantal_brieven)

if __name__ == '__main__':
    main()