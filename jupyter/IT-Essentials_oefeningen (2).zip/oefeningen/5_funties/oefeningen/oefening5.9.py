def hotel_kosten(aantal_nachten):
    prijs = 140.5 * aantal_nachten
    vermindering_3de_dag = (aantal_nachten // 3) * 140.5
    return prijs - vermindering_3de_dag

def vliegtuig_kosten(stad):
    if stad == "Barcelona":
        prijs = 183
    elif stad == "Rome":
        prijs = 220
    elif stad == "Betlijn":
        prijs = 125
    else:
        prijs = 450
    return prijs

def huurauto_kosten(aantal_dagen):
    kost = aantal_dagen * 40

    if aantal_dagen > 7:
        kost -= 50
    elif aantal_dagen > 3:
        kost -= 20
    return kost

def reis_kosten(stad, aantal_dagen):
    return hotel_kosten(aantal_dagen) + vliegtuig_kosten(stad) + huurauto_kosten(aantal_dagen)

def main():
    stad = input("Geef een stad in: ")
    if stad != "Barcelona" and stad != "Rome" and stad != "Berlijn" and stad != "Oslo":
        print("Verkeerde stad ingegeven.")
    else:
        aantal_dagen = int(input("Geef het aantal dagen in: "))
        prijs = reis_kosten(stad, aantal_dagen)
        print("Totale prijs:", prijs)

if __name__ == '__main__':
    main()
















