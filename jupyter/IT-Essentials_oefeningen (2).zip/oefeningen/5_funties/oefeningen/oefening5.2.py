def bepaal_schrikkeljaar(jaar):
    return ((jaar % 4 == 0 and jaar % 100 != 0) or (jaar % 400 == 0))

def main():
    jaar = int(input("Geef een jaartal in: "))
    print(bepaal_schrikkeljaar(jaar))

if __name__ == '__main__':
    main()